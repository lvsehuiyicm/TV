package androidx.media3.common.text;

import java.util.Objects;

public final class SubtitleOffsets {

  public static final SubtitleOffsets ZERO = new SubtitleOffsets(0, 0);

  public final long primaryMs;
  public final long secondaryMs;

  public SubtitleOffsets(long primaryMs, long secondaryMs) {
    this.primaryMs = primaryMs;
    this.secondaryMs = secondaryMs;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) return true;
    if (!(obj instanceof SubtitleOffsets other)) return false;
    return primaryMs == other.primaryMs && secondaryMs == other.secondaryMs;
  }

  @Override
  public int hashCode() {
    return Objects.hash(primaryMs, secondaryMs);
  }
}
