package androidx.media3.effect;

import androidx.media3.common.Effect;

public final class ColorToneAdjustEffect implements Effect {

  public ColorToneAdjustEffect() {}

  public void setAdjustment(VideoAdjustment adjustment) {}
}
