package androidx.media3.common.audio;

import java.nio.ByteBuffer;

public final class AudioEffectProcessor extends BaseAudioProcessor {

  public AudioEffectProcessor() {}

  @Override
  public void queueInput(ByteBuffer inputBuffer) {}

  public void setParameters(AudioEffectParameters parameters, boolean softwareEqualizer) {}

  public void resetParameters() {}
}
