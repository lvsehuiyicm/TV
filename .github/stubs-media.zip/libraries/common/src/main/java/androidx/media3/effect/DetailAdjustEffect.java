package androidx.media3.effect;

import androidx.media3.common.Effect;

public final class DetailAdjustEffect implements Effect {

  public DetailAdjustEffect() {}

  public void setAdjustment(VideoAdjustment adjustment) {}
}
