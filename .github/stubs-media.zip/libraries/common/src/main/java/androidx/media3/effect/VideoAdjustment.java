package androidx.media3.effect;

public final class VideoAdjustment {

  public static final class Builder {

    public Builder setSaturation(float saturation) {
      return this;
    }

    public Builder setContrast(float contrast) {
      return this;
    }

    public Builder setBrightness(float brightness) {
      return this;
    }

    public Builder setGamma(float gamma) {
      return this;
    }

    public Builder setHue(float hue) {
      return this;
    }

    public Builder setRedGain(float redGain) {
      return this;
    }

    public Builder setBlueGain(float blueGain) {
      return this;
    }

    public Builder setSharpness(float sharpness) {
      return this;
    }

    public Builder setThreshold(float threshold) {
      return this;
    }

    public Builder setShadowLift(float shadowLift) {
      return this;
    }

    public VideoAdjustment build() {
      return new VideoAdjustment();
    }
  }
}
