package androidx.media3.common.text;

import java.util.List;

public final class SubtitleContent {

  public static final SubtitleContent LOADING = new SubtitleContent(State.LOADING, List.of());
  public static final SubtitleContent UNSUPPORTED =
      new SubtitleContent(State.UNSUPPORTED, List.of());

  public final State state;
  public final List<Entry> entries;

  public SubtitleContent(State state, List<Entry> entries) {
    this.state = state;
    this.entries = entries;
  }

  public enum State {
    LOADING,
    ERROR,
    UNSUPPORTED,
    PARTIAL,
    TRUNCATED,
    COMPLETE
  }

  public static final class Entry {
    public boolean image;
    public String text;
    public long startTimeUs;
    public long endTimeUs;
  }
}
