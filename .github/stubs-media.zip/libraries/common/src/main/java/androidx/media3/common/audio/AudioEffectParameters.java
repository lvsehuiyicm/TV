package androidx.media3.common.audio;

public final class AudioEffectParameters {

  public static final AudioEffectParameters DEFAULT = new AudioEffectParameters();

  public static boolean isCenterGainAvailable(int channelCount) {
    return false;
  }

  public boolean hasEffect() {
    return false;
  }

  public boolean hasBands() {
    return false;
  }

  public boolean hasCenterGain(int channelCount) {
    return false;
  }

  public float getCenterGainFactor() {
    return 0.0f;
  }

  public int getChannelMode() {
    return AudioChannelMode.AUTO;
  }

  public float getBalance() {
    return 0.0f;
  }

  public boolean isLoudnessEnabled() {
    return false;
  }

  public float getStability() {
    return 0.0f;
  }

  public int getBoostMillibels() {
    return 0;
  }

  public int getPreampMillibels() {
    return 0;
  }

  public short[] getEqualizerLevelsMillibels() {
    return new short[0];
  }

  public boolean shouldLimitOutput(int channelCount) {
    return false;
  }

  public static final class Builder {

    public Builder setEqualizerBands(int[] frequencies, short[] levels) {
      return this;
    }

    public Builder setStability(float stability) {
      return this;
    }

    public Builder setBoostMillibels(int boostMillibels) {
      return this;
    }

    public Builder setPreampMillibels(int preampMillibels) {
      return this;
    }

    public Builder setCenterGainMillibels(int centerGainMillibels) {
      return this;
    }

    public Builder setBalance(float balance) {
      return this;
    }

    public Builder setChannelMode(int channelMode) {
      return this;
    }

    public Builder setLoudnessEnabled(boolean loudnessEnabled) {
      return this;
    }

    public AudioEffectParameters build() {
      return new AudioEffectParameters();
    }
  }
}
