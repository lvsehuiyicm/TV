package androidx.media3.common.text;

import androidx.annotation.Nullable;
import androidx.media3.common.TrackSelectionOverride;
import java.util.Objects;

public final class SubtitleSelectionState {

  public static final SubtitleSelectionState EMPTY = new SubtitleSelectionState(null, null);

  @Nullable public final TrackSelectionOverride primarySelection;
  @Nullable public final TrackSelectionOverride activeSecondarySelection;

  public SubtitleSelectionState(
      @Nullable TrackSelectionOverride primarySelection,
      @Nullable TrackSelectionOverride activeSecondarySelection) {
    this.primarySelection = primarySelection;
    this.activeSecondarySelection = activeSecondarySelection;
  }

  public boolean isPrimary(@Nullable TrackSelectionOverride selection) {
    return Objects.equals(selection, primarySelection);
  }

  public boolean isActiveSecondary(@Nullable TrackSelectionOverride selection) {
    return Objects.equals(selection, activeSecondarySelection);
  }
}
