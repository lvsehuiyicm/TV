package androidx.media3.common.util;

import androidx.media3.common.MediaItem;
import java.util.Collections;
import java.util.Map;

public final class LocalClearKeyLicense {

  private LocalClearKeyLicense() {}

  public static Map<String, String> parse(String license) {
    return Collections.emptyMap();
  }

  public static Map<String, String> parse(MediaItem.DrmConfiguration drmConfiguration) {
    return Collections.emptyMap();
  }
}
