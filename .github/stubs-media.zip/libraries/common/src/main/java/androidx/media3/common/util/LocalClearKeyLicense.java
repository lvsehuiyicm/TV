package androidx.media3.common.util;

import androidx.media3.common.MediaItem;
import java.util.Map;

public final class LocalClearKeyLicense {

  private LocalClearKeyLicense() {}

  public static Map<String, String> parse(String license) {
    return Map.of();
  }

  public static Map<String, String> parse(MediaItem.DrmConfiguration drmConfiguration) {
    return Map.of();
  }
}
