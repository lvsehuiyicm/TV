package androidx.media3.common;

public final class VideoTransform {

  public static final float MAX_SCALE = 8.0f; // 值未验证：用法只要求能做上限校验，取约定值

  public final float scaleX;
  public final float scaleY;
  public final float panX;
  public final float panY;

  public VideoTransform(float scaleX, float scaleY, float panX, float panY) {
    this.scaleX = scaleX;
    this.scaleY = scaleY;
    this.panX = panX;
    this.panY = panY;
  }
}
