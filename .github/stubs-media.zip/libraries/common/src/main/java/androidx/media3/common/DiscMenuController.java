package androidx.media3.common;

import java.util.function.Consumer;

public interface DiscMenuController {

  enum OpenResult {
    RUNTIME_MISSING,
    UNAVAILABLE,
    TIMED_OUT
  }

  boolean open(String action, Consumer<OpenResult> callback);

  boolean isActive();

  boolean isNavigationPlayback();

  boolean sendAction(String action);

  boolean supportsPointer();
}
