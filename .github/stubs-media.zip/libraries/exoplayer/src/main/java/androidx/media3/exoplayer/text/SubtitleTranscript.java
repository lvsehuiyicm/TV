package androidx.media3.exoplayer.text;

public final class SubtitleTranscript {}
