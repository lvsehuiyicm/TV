package androidx.media3.exoplayer.libass;

import java.io.File;
import java.io.IOException;

public final class LibassFontFile {

  private LibassFontFile() {}

  public static String getFamilyName(File file) throws IOException {
    return null;
  }
}
