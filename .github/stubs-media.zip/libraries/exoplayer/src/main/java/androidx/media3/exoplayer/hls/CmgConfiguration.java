package androidx.media3.exoplayer.hls;

import android.net.Uri;
import androidx.annotation.Nullable;

public final class CmgConfiguration {

  private CmgConfiguration() {}

  @Nullable
  public static CmgConfiguration fromMediaUri(Uri uri) {
    return null;
  }
}
