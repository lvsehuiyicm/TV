package androidx.media3.exoplayer.source;

import androidx.media3.common.MediaItem;
import androidx.media3.datasource.DataSource;
import androidx.media3.exoplayer.drm.DrmSessionManagerProvider;
import androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy;

public final class ContentTypeResolvingMediaSource {

  public static final class Factory implements MediaSource.Factory {

    private final MediaSource.Factory factory;
    private final DataSource.Factory dataSourceFactory;

    public Factory(MediaSource.Factory factory, DataSource.Factory dataSourceFactory) {
      this.factory = factory;
      this.dataSourceFactory = dataSourceFactory;
    }

    @Override
    public MediaSource createMediaSource(MediaItem mediaItem) {
      return factory.createMediaSource(mediaItem);
    }

    @Override
    public int[] getSupportedTypes() {
      return factory.getSupportedTypes();
    }

    @Override
    public Factory setDrmSessionManagerProvider(
        DrmSessionManagerProvider drmSessionManagerProvider) {
      factory.setDrmSessionManagerProvider(drmSessionManagerProvider);
      return this;
    }

    @Override
    public Factory setLoadErrorHandlingPolicy(LoadErrorHandlingPolicy loadErrorHandlingPolicy) {
      factory.setLoadErrorHandlingPolicy(loadErrorHandlingPolicy);
      return this;
    }
  }
}
