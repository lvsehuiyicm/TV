package androidx.media3.exoplayer.source;

import androidx.media3.common.C;

public final class EndTrimMediaSource extends WrappingMediaSource {

  private long endTrimDurationMs;

  public EndTrimMediaSource(MediaSource source, long endTrimDurationMs) {
    super(source);
    this.endTrimDurationMs = endTrimDurationMs;
  }

  public void setEndTrimDurationMs(long endTrimDurationMs) {
    this.endTrimDurationMs = endTrimDurationMs;
  }

  public boolean isEndTrimActive() {
    return endTrimDurationMs > 0;
  }

  public long getOriginalDurationMs() {
    return C.TIME_UNSET;
  }

}
