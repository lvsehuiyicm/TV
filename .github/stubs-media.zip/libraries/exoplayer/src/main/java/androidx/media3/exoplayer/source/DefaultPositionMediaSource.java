package androidx.media3.exoplayer.source;

public final class DefaultPositionMediaSource extends WrappingMediaSource {

  private final long positionMs;

  public DefaultPositionMediaSource(MediaSource source, long positionMs) {
    super(source);
    this.positionMs = positionMs;
  }

}
