package androidx.media3.exoplayer.iso;

import androidx.media3.common.MediaItem;

public final class IsoDiscPreparation {

  private IsoDiscPreparation() {}

  public static boolean isIso(MediaItem mediaItem) {
    return false;
  }
}
