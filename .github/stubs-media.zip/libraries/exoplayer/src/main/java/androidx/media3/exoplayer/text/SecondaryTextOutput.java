package androidx.media3.exoplayer.text;

import androidx.media3.common.text.CueGroup;

public final class SecondaryTextOutput implements TextOutput {

  public SecondaryTextOutput() {}

  @Override
  public void onCues(CueGroup cueGroup) {}
}
