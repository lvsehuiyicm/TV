package androidx.media3.decoder.ffmpeg;

import android.content.Context;
import androidx.media3.exoplayer.DecoderManager;
import androidx.media3.exoplayer.DefaultRenderersFactory;

public class FfmpegMotionRenderersFactory extends DefaultRenderersFactory {

  public FfmpegMotionRenderersFactory(
      Context context, int motionFps, int motionResolution, boolean motionEnabled) {
    super(context);
  }

  public void setDecoderManager(DecoderManager decoderManager) {}

  public void setEnableSurfaceControlFrameRetention(boolean enabled) {}
}
