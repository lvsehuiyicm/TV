package androidx.media3.exoplayer.iso;

import android.content.Context;
import androidx.annotation.Nullable;
import androidx.media3.common.DiscMenuController;
import androidx.media3.common.Player;
import androidx.media3.datasource.DataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.MediaSource;
import java.util.function.Consumer;

public final class IsoNavigationPlayerController implements DiscMenuController {

  private final ExoPlayer player;

  public IsoNavigationPlayerController(ExoPlayer player) {
    this.player = player;
  }

  public Player getPlayer() {
    return player;
  }

  @Nullable
  public MediaSource prepareMediaSource(
      Context context, MediaSource mediaSource, DataSource.Factory dataSourceFactory) {
    return mediaSource;
  }

  public boolean isStarted() {
    return false;
  }

  public void close() {}

  @Override
  public boolean open(String action, Consumer<OpenResult> callback) {
    return false;
  }

  @Override
  public boolean isActive() {
    return false;
  }

  @Override
  public boolean isNavigationPlayback() {
    return false;
  }

  @Override
  public boolean sendAction(String action) {
    return false;
  }

  @Override
  public boolean supportsPointer() {
    return false;
  }
}
