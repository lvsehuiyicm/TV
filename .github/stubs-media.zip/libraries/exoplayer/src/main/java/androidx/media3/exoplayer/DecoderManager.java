package androidx.media3.exoplayer;

import android.content.Context;
import androidx.media3.exoplayer.trackselection.DecodeTrackSelector;

public final class DecoderManager {

  private final DecoderMode audioMode;
  private final DecoderMode videoMode;

  public DecoderManager(DecoderMode audioMode, DecoderMode videoMode) {
    this.audioMode = audioMode;
    this.videoMode = videoMode;
  }

  public DecoderMode getAudioMode() {
    return audioMode;
  }

  public DecoderMode getVideoMode() {
    return videoMode;
  }

  public void selectAudioDecoder(DecoderMode mode) {}

  public void selectVideoDecoder(DecoderMode mode) {}

  public DecodeTrackSelector createTrackSelector(Context context) {
    return new DecodeTrackSelector(context);
  }

  public void attach(ExoPlayer player) {}

  public void detach() {}
}
