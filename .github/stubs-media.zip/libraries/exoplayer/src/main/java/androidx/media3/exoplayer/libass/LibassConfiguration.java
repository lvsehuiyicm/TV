package androidx.media3.exoplayer.libass;

import androidx.annotation.Nullable;

public final class LibassConfiguration {

  public static final class Builder {

    public Builder setFontConfig(@Nullable String fontConfig) {
      return this;
    }

    public Builder setFontsDirectory(@Nullable String fontsDirectory) {
      return this;
    }

    public Builder setDefaultFontFamily(@Nullable String defaultFontFamily) {
      return this;
    }

    public Builder setMaximumRenderPixels(int maximumRenderPixels) {
      return this;
    }

    public Builder setMaximumGlyphCount(int maximumGlyphCount) {
      return this;
    }

    public Builder setMaximumBitmapCacheSizeMb(int maximumBitmapCacheSizeMb) {
      return this;
    }

    public LibassConfiguration build() {
      return new LibassConfiguration();
    }
  }
}
