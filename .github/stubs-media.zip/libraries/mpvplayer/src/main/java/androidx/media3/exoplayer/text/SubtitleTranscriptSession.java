package androidx.media3.exoplayer.text;

import androidx.annotation.Nullable;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.text.SubtitleContent;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.mpvplayer.MpvSubtitleContentLoader;

public final class SubtitleTranscriptSession {

  public SubtitleTranscriptSession() {}

  public void setLoader(MpvSubtitleContentLoader loader) {}

  public void setPlayer(ExoPlayer player) {}

  public void setPreloadMediaItem(@Nullable MediaItem mediaItem) {}

  public void close() {}

  public SubtitleTranscript forMediaItem(MediaItem mediaItem) {
    return new SubtitleTranscript();
  }

  public SubtitleContent getContent(Format format, long positionMs) {
    return SubtitleContent.UNSUPPORTED;
  }
}
