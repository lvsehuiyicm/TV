package androidx.media3.mpvplayer;

public enum MpvDecoderMode {
  AUTO,
  HARDWARE,
  SOFTWARE,
  FFMPEG;

  public static MpvDecoderMode fromCommonDecoderMode(androidx.media3.common.DecoderMode mode) {
    if (mode == null) return null;
    return MpvDecoderMode.valueOf(mode.name());
  }

  public androidx.media3.common.DecoderMode toCommonDecoderMode() {
    return androidx.media3.common.DecoderMode.valueOf(name());
  }
}
