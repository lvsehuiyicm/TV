package androidx.media3.mpvplayer;

import androidx.annotation.Nullable;
import java.io.File;
import java.util.Collections;
import java.util.Set;

public final class MpvConfigFileInspector {

  public MpvConfigFileInspector(File mpvDirectory) {}

  @Nullable
  public File readSubtitleFontsDirectory() {
    return null;
  }

  public Set<String> getEffectiveOptionNames(CharSequence content) {
    return Collections.emptySet();
  }
}
