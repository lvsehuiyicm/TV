package androidx.media3.common.audio;

public final class AudioChannelMix {

  private AudioChannelMix() {}

  public static float[][] createFrontCenterGainMix(int channelCount, float centerGainFactor) {
    return androidx.media3.mpvplayer.audio.AudioChannelMix.createFrontCenterGainMix(
        channelCount, centerGainFactor);
  }

  public static float[][] createStereoMix(int channelCount, boolean reverse) {
    return androidx.media3.mpvplayer.audio.AudioChannelMix.createStereoMix(channelCount, reverse);
  }

  public static float[][] createMonoMix(int channelCount) {
    return androidx.media3.mpvplayer.audio.AudioChannelMix.createMonoMix(channelCount);
  }

  public static float[][] createFrontBalanceMix(int channelCount, float balance) {
    return androidx.media3.mpvplayer.audio.AudioChannelMix.createFrontBalanceMix(channelCount, balance);
  }

  public static float[][] compose(float[][] first, float[][] second) {
    return androidx.media3.mpvplayer.audio.AudioChannelMix.compose(first, second);
  }
}
